--
-- backup20150701-233314.sql.gz


DROP TABLE IF EXISTS `affaire`;
CREATE TABLE `affaire` (
  `id` bigint(20) NOT NULL,
  `tranche_id` bigint(20) NOT NULL,
  `type_combustible` varchar(15) NOT NULL COMMENT 'Coil / Gaz / Wood / Nuclear / Wind / Hydro / Sea / Combined',
  `annee_contrat` char(4) NOT NULL COMMENT 'nom de la colonne dans ancienne base Client : contract_award',
  `gamme_id` int(11) NOT NULL,
  `aff_desc` varchar(100) NOT NULL COMMENT 'nom de la colonne dans ancienne base Client : Process_d',
  `comment` varchar(255) DEFAULT NULL COMMENT 'Indiquer si par exemple la tranche a ete renove le nom du concurent. Exemple pour Gardanne 4 TGC renove  par Emerson.',
  `statut_produit` varchar(40) DEFAULT NULL COMMENT 'Indiquer ici si le produit est actif, perdu, arr�t exploitation, cocon, r�nov� par concurrence',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_site_aff` (`tranche_id`,`type_combustible`,`annee_contrat`,`gamme_id`,`aff_desc`),
  KEY `IDX_gamme` (`gamme_id`),
  CONSTRAINT `FK_affaire_gamme` FOREIGN KEY (`gamme_id`) REFERENCES `gamme` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_affaire_tranche` FOREIGN KEY (`tranche_id`) REFERENCES `tranche` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `gamme`;
CREATE TABLE `gamme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `system` varchar(30) NOT NULL COMMENT 'Indiquer le type de systeme uniquement : DCS / TGC / AVR / EXCIT / SYNCHRO / IPB / SSS.',
  `nameGamme` varchar(30) NOT NULL COMMENT 'Indiquer uniquement la gamme du systeme : P320 / Microrec 1er / Microrec K / Generec / STG820 /Remodem / REC70 / Controsteam / �..',
  `version` varchar(10) NOT NULL DEFAULT ' ' COMMENT 'Indiquer uniquement la version dans la gamme. Exemple pour le syst�me TGC dans la gamme P320 : A / V1 / V1+ / V2 / V2+.',
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_gamme` (`system`,`nameGamme`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `nomenclature`;
CREATE TABLE `nomenclature` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `affaire_id` bigint(20) NOT NULL,
  `nameNomenc` varchar(30) NOT NULL,
  `description` varchar(255) DEFAULT NULL COMMENT 'Preciser si la nomenclature concerne Armoire de regulation, Armoire HMI, Armoire electrique',
  `date_import` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_nomenclature` (`affaire_id`,`nameNomenc`),
  CONSTRAINT `FK_nomenclature_affaire` FOREIGN KEY (`affaire_id`) REFERENCES `affaire` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `nomenclature_doc`;
CREATE TABLE `nomenclature_doc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomenclature_id` bigint(20) NOT NULL,
  `nom_fich` varchar(255) NOT NULL COMMENT 'verifier si nom_fich UNIQUE ou faut-il y associer le PATH',
  `doc_path` varchar(255) DEFAULT NULL,
  `doc_type` varchar(45) DEFAULT NULL,
  `doc_titre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_nomenc_doc` (`nomenclature_id`,`nom_fich`),
  CONSTRAINT `FK_nomenc_doc_nomenc` FOREIGN KEY (`nomenclature_id`) REFERENCES `nomenclature` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `nomenclature_piece`;
CREATE TABLE `nomenclature_piece` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nomenclature_id` bigint(20) NOT NULL,
  `nomenclature_lg` int(11) NOT NULL COMMENT 'num�ro de ligne dans le fichier excel',
  `repere` varchar(20) NOT NULL,
  `recobj` varchar(20) DEFAULT NULL,
  `codeArticle_pref` varchar(5) NOT NULL COMMENT 'Prefixe PMX a renseigner au moment import',
  `codeArticle_nomenc` varchar(20) NOT NULL COMMENT 'code article tel que reference dans la nomenclature',
  `piece_id` bigint(20) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix` int(11) DEFAULT NULL,
  `devise` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_nomenc_piece` (`nomenclature_id`,`nomenclature_lg`),
  KEY `IDX_article` (`piece_id`),
  CONSTRAINT `FK_nomenc_piece_nomenc` FOREIGN KEY (`nomenclature_id`) REFERENCES `nomenclature` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_nomenc_piece_piece` FOREIGN KEY (`piece_id`) REFERENCES `piece` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `pac`;
CREATE TABLE `pac` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomPac` varchar(50) NOT NULL,
  `nomPacEn` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_nomPac` (`nomPac`),
  UNIQUE KEY `UNI_nomPacEn` (`nomPacEn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `pays`;
CREATE TABLE `pays` (
  `id` int(11) NOT NULL,
  `nomPays` varchar(50) NOT NULL,
  `nomPaysEn` varchar(50) NOT NULL,
  `pac_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_nomPays` (`nomPays`),
  UNIQUE KEY `UNI_nomPaysEn` (`nomPaysEn`),
  KEY `IDX_pac` (`pac_id`),
  KEY `fk_pays_region1_idx` (`region_id`),
  CONSTRAINT `FK_pays_pac` FOREIGN KEY (`pac_id`) REFERENCES `pac` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_pays_region` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `piece`;
CREATE TABLE `piece` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `codeArticle` varchar(30) NOT NULL COMMENT 'contient le prefix PMX',
  `codeArticle_anc` varchar(30) DEFAULT NULL COMMENT 'ancien code article VOIR si dans cette table ou dans nomclature_piece',
  `type_id` bigint(20) DEFAULT NULL,
  `descriptionFr` varchar(255) DEFAULT NULL,
  `descriptionEn` varchar(255) DEFAULT NULL,
  `designation_d` varchar(255) DEFAULT NULL COMMENT 'deutch ',
  `designation_e` varchar(255) DEFAULT NULL COMMENT 'espagnol',
  `designation_i` varchar(255) DEFAULT NULL COMMENT 'italien',
  `designation_baan` varchar(255) DEFAULT NULL,
  `fournisseur` varchar(50) DEFAULT NULL,
  `refFournisseur` varchar(50) DEFAULT NULL,
  `statut` varchar(20) DEFAULT NULL COMMENT 'Active, Obsolete, Remplacee, Discontinue, Mature, Inconnue',
  `reparable` varchar(10) DEFAULT NULL COMMENT 'Oui, Non, peut-etre',
  `risque` varchar(10) DEFAULT NULL COMMENT 'Haut, Moyen, Bas ',
  `consomation` varchar(20) DEFAULT NULL COMMENT 'A : Beaucoup, B : Moyen, C : Peu, Ponctuel, D : Nul',
  `personnalisation` char(3) DEFAULT NULL COMMENT 'Oui / Non',
  `essais` char(3) DEFAULT NULL COMMENT 'Oui / Non',
  `mtbf` bigint(20) DEFAULT NULL,
  `firmware` varchar(255) DEFAULT NULL,
  `boolSolution` char(3) DEFAULT NULL COMMENT 'Oui / Non',
  `solution` varchar(20) DEFAULT NULL COMMENT '�quivalence, renouvel�e, mise � niveau',
  `descriptionSolution` varchar(255) DEFAULT NULL,
  `miseEnOeuvre` varchar(255) DEFAULT NULL,
  `nom` varchar(30) DEFAULT NULL,
  `certification` varchar(10) DEFAULT NULL COMMENT 'SIL2, SIL3',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_codeArticle` (`codeArticle`),
  KEY `IDX_type` (`type_id`),
  KEY `IDX_fournisseur` (`fournisseur`),
  KEY `IDX_ref_fournisseur` (`refFournisseur`),
  CONSTRAINT `FK_piece_type` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `piece_doc`;
CREATE TABLE `piece_doc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `piece_id` bigint(20) NOT NULL,
  `nom_fich` varchar(255) NOT NULL COMMENT 'verifier si nom_fich UNIQUE ou faut-il y associer le PATH',
  `doc_path` varchar(255) DEFAULT NULL,
  `doc_type` varchar(45) DEFAULT NULL,
  `doc_titre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_piece_doc` (`piece_id`,`nom_fich`),
  CONSTRAINT `FK_piece_doc_piece` FOREIGN KEY (`piece_id`) REFERENCES `piece` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `region`;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomRegion` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_region` (`nomRegion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role` int(11) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK358076E95446B2` (`user_id`),
  CONSTRAINT `FK358076E95446B2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `site`;
CREATE TABLE `site` (
  `id` int(11) NOT NULL,
  `nameSite` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `pays_id` int(11) DEFAULT NULL,
  `client` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_nameSite` (`nameSite`),
  KEY `IDX_pays` (`pays_id`),
  KEY `IDX_client` (`client`),
  CONSTRAINT `FK_site_pays` FOREIGN KEY (`pays_id`) REFERENCES `pays` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `tranche`;
CREATE TABLE `tranche` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `nameTranche` varchar(10) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_site_tranche` (`site_id`,`nameTranche`),
  CONSTRAINT `FK_tranche_site` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nameType` varchar(20) NOT NULL,
  `nameTypeEn` varchar(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `formule_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_nameType` (`nameType`),
  UNIQUE KEY `UNI_nameTypeEn` (`nameTypeEn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountType` varchar(255) DEFAULT NULL,
  `createadBy` int(11) NOT NULL,
  `createdDate` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastLoggedIn` date DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `mobilePhone` varchar(255) DEFAULT NULL,
  `modifiedBy` int(11) NOT NULL,
  `modifiedDate` date DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `officePhone` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
